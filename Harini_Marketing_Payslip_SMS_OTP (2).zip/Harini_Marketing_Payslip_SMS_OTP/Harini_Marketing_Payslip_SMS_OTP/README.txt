HARINI HOSPITALS - MARKETING PAYSLIP PORTAL WITH SMS OTP
========================================================

WHAT IS INCLUDED
- Existing local payslip website (admin + employee dashboards)
- Employee forgot-password dialog
- Indian mobile number validation (+91)
- MSG91 SMS OTP send and verify calls from a Node.js backend
- Basic per-number resend throttling (60 seconds; 5 sends/hour, in-memory)
- Employee password update in the existing browser localStorage demo

IMPORTANT SECURITY LIMITATION
This is an integration demonstration, NOT a production payroll authentication system.
The existing app stores employee records and passwords in browser localStorage.
The browser currently checks the employee ID/mobile match locally, so a user who can
modify browser storage can bypass that check. After SMS OTP verification, the demo
updates the password in localStorage. Do not use real payroll data or rely on this
for confidential employee accounts.

For production, move employee profiles, registered phone numbers, password hashes,
payslips and reset sessions into a server-side database. The backend must look up
the employee ID + verified mobile itself, issue a short-lived one-time reset token,
and update a securely hashed password server-side. Add HTTPS, CSRF/session controls,
persistent rate limits, audit logs, backups and admin MFA.

REQUIREMENTS
- Windows 10/11
- Node.js 18 or newer
- MSG91 account with OTP API enabled
- Approved OTP template / required Indian DLT configuration

STEP 1 - MSG91 ACCOUNT SETUP
1. Create/sign in to MSG91: https://msg91.com/
2. Open OTP and create an OTP template.
3. Configure a 6-digit OTP and 5-minute expiry (or matching values in .env).
4. Complete the applicable Indian DLT entity, header/sender ID and template registration
   process as requested by MSG91 and the telecom operators.
5. Copy your MSG91 Auth Key and the OTP Template ID.
6. Check the template is approved/active before testing.

STEP 2 - INSTALL NODE.JS
1. Download Node.js LTS from https://nodejs.org/
2. Install it, keeping the default options.
3. Close and reopen Command Prompt.
4. Check:
   node -v
   npm -v
   Node should be version 18 or newer.

STEP 3 - CONFIGURE THIS PROJECT
1. Extract this ZIP.
2. Open the extracted folder.
3. Rename .env.example to .env.
4. Open .env in Notepad.
5. Replace PASTE_YOUR_MSG91_AUTHKEY_HERE with your real Auth Key.
6. Replace PASTE_YOUR_APPROVED_OTP_TEMPLATE_ID_HERE with your OTP Template ID.
7. Save .env. Do not share it or commit it to GitHub.

STEP 4 - START WEBSITE
1. In the project folder, click the address bar in File Explorer, type cmd and press Enter.
2. Run:
   npm install
3. Then run:
   npm start
4. Open this address in Chrome:
   http://localhost:3000
Do not double-click index.html for SMS testing. Open through localhost so the browser
can call the Node.js backend.

STEP 5 - ADD EMPLOYEE MOBILE NUMBER
1. Sign in as admin:
   username: admin
   password: Admin@123
2. Add an employee.
3. Enter a valid 10-digit Indian mobile number in the Phone field.
4. Save the employee.
5. For this local demo, employee login password is initially Welcome@123.

STEP 6 - TEST FORGOT PASSWORD
1. Sign out.
2. Select Marketing Employee.
3. Click "Forgot Password? (Employee)".
4. Enter the employee ID and the same registered mobile number.
5. Click Send OTP. Check the phone's SMS inbox.
6. Enter the 6-digit OTP and click Verify OTP.
7. Enter and confirm a new password (at least 8 characters).
8. Click Update password.
9. Sign in with the employee ID and new password.

TROUBLESHOOTING
- SMS not received: check MSG91 wallet/account status, approved template, template ID,
  DLT/entity/header configuration, number format, and MSG91 OTP logs.
- "SMS service is not configured": .env is missing or values are not set; restart npm start.
- Port already in use: change PORT=3001 in .env and open http://localhost:3001.
- npm is not recognized: reinstall Node.js and reopen Command Prompt.
- If you edit .env while server is running, stop it with Ctrl+C and run npm start again.

API NOTES
This project uses MSG91's documented SendOTP endpoint:
POST https://control.msg91.com/api/v5/otp?template_id=...&mobile=...
and Verify OTP endpoint:
GET https://control.msg91.com/api/v5/otp/verify?mobile=...&otp=...
The Auth Key is sent as a server-side request header. See official docs:
https://docs.msg91.com/otp
https://docs.msg91.com/otp/sendotp
https://msg91.com/help/sendotp/step-by-step-process-to-configure-sendotp
